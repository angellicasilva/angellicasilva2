<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Responsive Medical Clinic Hospital Template">
        <meta name="author" content="Minimalthemes">
        <title>Home | Medical Care</title>
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="<?php echo BASEURL; ?>assets/images/favicon.png">
        <!-- Bootstrap core CSS -->
        <link href="<?php echo BASEURL; ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Link Swiper  CSS -->
        <link rel="stylesheet" href="<?php echo BASEURL; ?>assets/css/swiper.min.css">
        <!-- OWL Carousel CSS -->
        <link rel="stylesheet" href="<?php echo BASEURL; ?>assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="<?php echo BASEURL; ?>assets/css/owl.theme.default.min.css">
        <!-- Fontsawesome CSS -->
        <link rel="stylesheet" href="<?php echo BASEURL; ?>assets/css/font-awesome.min.css">
        <!-- Custom styles for this template -->
        <link href="<?php echo BASEURL; ?>style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <body>
        <!-- Section Navbar -->
        <nav id="section-navbar" class="navbar navbar-default"> 
            <div class="container"> 
                <div class="navbar-header"> 
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> 
                        <span class="sr-only">Toggle navigation</span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                    </button>                     
                    <a class="navbar-brand" href="<?php echo BASEURL; ?>">
                        <img src="<?php echo BASEURL; ?>assets/images/logo.png" style="max-width:80%" class="img-responsive" alt="Medicalcare-Image" />
                    </a>                     
                </div>                 
                <!-- Header Serach Button -->
                <a href="#" class="pull-right search-btn glyphicon glyphicon-search" data-toggle="modal" data-target="#searchmodal"></a>
                <!-- /.Header Serach Button -->                 
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1"> 
                    <ul class="nav navbar-nav navbar-right"> 
                        <li class="active">
                            <a href="<?php echo BASEURL; ?>">Home</a>
                        </li>
                        <li>
                            <a href="">Menu1</a>
                        </li> 
                        <li>
                            <a href="">Menu2</a>
                        </li>                       
                        <li>
                            <a href="">Menu3</a>
                        </li> 
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu com Submenu
                            <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="">Opção 1</a></li>
                                <li><a href="">Opção 2</a></li>
                                <li><a href="">Opção 3</a></li>
                                <li><a href="">Opção 4</a></li>
                                <li><a href="">Opção 5</a></li>
                                <li><a href="">Opção 6</a></li>
                                <li><a href="">Opção 7</a></li>
                                
                            </ul>
                        </li>                         
                    </ul>                     
                </div>                 
            </div>             
        </nav>
        <!-- /.Section Navbar -->





