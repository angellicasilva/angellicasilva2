<!-- Section Footer -->
        <div id="section-footer" class="container-fluid">
            <div class="container">
                <div class="row">
                    <!-- Footer Column 1 -->
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div class="ft_title">
                            <h4>Cadastre-se para receber nossas novidades!</h4>
                        </div>
                        <!-- Form Newsletter Sign Up -->
                        <form class="ft_newsletter_signup"> 
                            <div class="col-md-5 col-sm-6 col-xs-6 input"> 
                                <input type="text" class="form-control" placeholder="Nome" required> 
                            </div>
                            <div class="col-md-5 col-sm-6 col-xs-6 input"> 
                                <input type="email" class="form-control" placeholder="Email" required> 
                            </div>
                            <div class="col-md-2 col-sm-12 col-xs-12 submit">
                                <button type="submit" class="btn">Cadastrar</button>
                            </div>
                        </form>                         
                        <!-- /.Form Newsletter Sign Up -->
                        <!-- Latest-tweets -->
                        <div class="latest-tweets owl-carousel owl-theme col-md-12 col-sm-12 col-xs-12 p-0">
                            <div class="item">
                                <h4><i class="fa fa-twitter"></i>Últimos Tweets</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing<br>and typesetting industry. </p>
                                <p>@envato 8 horas atrás</p>
                            </div>
                            <div class="item">
                                <h4><i class="fa fa-twitter"></i>Últimos Tweets</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing<br>and typesetting industry. </p>
                                <p>@envato 8 horas atrás</p>
                            </div>
                            <div class="item">
                                <h4><i class="fa fa-twitter"></i>Últimos Tweets</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing<br>and typesetting industry. </p>
                                <p>@envato 8 horas atrás</p>
                            </div>                             
                        </div>                         
                        <!-- /.Latest-tweets -->                         
                    </div>
                    <!-- /.Footer Column 1 -->
                    <!-- Footer Column 2 -->
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <div class="ft_title">
                            <h4>Últimas Notícias</h4>
                        </div>                         
                        <div class="ft_latestnews">
                            <a href="blog-post.html">
                                <div class="ft_latestnews_media">
                                    <img src="<?php echo BASEURL; ?>assets/images/footer-latestnews_1.png" alt="Medicalcare-Image" />
                                </div>
                                <div class="ft_latestnews_desc">
                                    <p>Lorem Ipsum is simply dummy</p>
                                    <p>October 14, 2018</p>
                                </div>
                            </a>
                        </div>
                        <div class="ft_latestnews">
                            <a href="blog-post.html">
                                <div class="ft_latestnews_media">
                                    <img src="<?php echo BASEURL; ?>assets/images/footer-latestnews_2.png" alt="Medicalcare-Image" />
                                </div>
                                <div class="ft_latestnews_desc">
                                    <p>Lorem Ipsum is simply dummy</p>
                                    <p>October 14, 2018</p>
                                </div>
                            </a>
                        </div>
                        <div class="ft_latestnews">
                            <a href="blog-post.html">
                                <div class="ft_latestnews_media">
                                    <img src="<?php echo BASEURL; ?>assets/images/footer-latestnews_3.png" alt="Medicalcare-Image" />
                                </div>
                                <div class="ft_latestnews_desc">
                                    <p>Lorem Ipsum is simply dummy</p>
                                    <p>October 14, 2018</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- /.Footer Column 2 -->
                    <!-- Footer Column 3 -->
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="ft_title">
                            <h4>Contao</h4> 
                        </div>                         
                        <div class="ft_contactus_desc"> 
                            <p>
	                        Consulta Fácil<br>
	                        1600 Divisadero Street Northeast<br>
	                        San Francisco,  CA 94115<br><br>
                            
	                        Tel: 1-800-700-6200<br>
							E-mail: info@bootstrapmart.com<Br><br></p>
                            <p><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-google-plus"></i></a></p> 
                        </div>
                    </div>
                    <!-- /.Footer Column 3 -->
                </div>
            </div>
            <div class="container ft_copyright">
                <div class="col-md-12 col-sm-12 col-xs-12"> 
                    <p>© Copyright 2020. Consulta Fácil</p> 
                </div>
            </div>
        </div>
        <!-- /.Section Footer -->
        <!-- Section Search ModalBox -->
        <div class="navbar-modal-search modal fade" id="searchmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <h2>Pesquisar</h2>
                    <form>
                        <input type="text" value="Enter your  keyword" onblur="if(this.value == '') { this.value ='O que você está procurando?'; }" onfocus="if(this.value =='Enter your  keyword') { this.value = ''; }">
                        <input type="submit" value="">
                        <i class="fa fa-search"></i>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.Section Search ModalBox -->
        <!-- JavaScript Cores
    	================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        
		 <script src="<?php echo BASEURL; ?>assets/js/jquery.min.js"></script>
        <script src="<?php echo BASEURL; ?>bootstrap/js/bootstrap.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="<?php echo BASEURL; ?>assets/js/ie10-viewport-bug-workaround.js"></script>
        <!-- Swiper JS -->
        <script src="<?php echo BASEURL; ?>assets/js/swiper.min.js"></script>
		
		
        <script src="<?php echo BASEURL; ?>assets/js/main.js"></script>
        <!-- OWL Carousel JS -->
        <script src="<?php echo BASEURL; ?>assets/js/owl.carousel.js"></script>
        <!-- GENERAL SCRIPTS -->
        <script src="<?php echo BASEURL; ?>assets/js/scripts.js"></script>
		
		
    </body>
</html>

