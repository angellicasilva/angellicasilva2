<?php	
require_once('../config.php');	
require_once(DBAPI);	
$medicos = null;	
$medico = null;	

/**	 *  Listagem de Médicos	 */	
function index() {		
global $medicos;		
$medicos = find_all('medicos');	}