<?php	
require_once('../config.php');	
require_once(DBAPI);	
$medicos = null;	
$medico = null;	

/**	 *  Listagem de Médicos	 */	
function index() {		
global $medicos;		
$medicos = find_all('medicos');	}



/**     *  Cadastro de Médicos     */
function add()
{
    if (!empty($_POST['medico'])) {
        $today                = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $medico             = $_POST['medico'];
        $medico['data_alteracao'] = $medico['data_criacao'] = $today->format("Y-m-d H:i:s");
        save('medicos', $medico);
        header('location: index.php');
    }
}


/**     *    Atualizacao/Edicao de Cliente     */
function edit()
{
    $now = date_create('now', new DateTimeZone('America/Sao_Paulo'));
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        if (isset($_POST['medico'])) {
            $medico             = $_POST['medico'];
            $medico['data_alteracao'] = $now->format("Y-m-d H:i:s");
            update('medicos', $id, $medico);
            header('location: index.php');
        } else {
            global $medico;
            $medico = find('medicos', $id);
        }
    } else {
        header('location: index.php');
    }
}

/**	 *  Exclusão de um Cliente	 */	
function delete($id = null) {	
	global $medico;	  
		$medico = remove('medicos', $id);	
	header('location: index.php');	}
	
	
	
	/**	 *  Visualização de um Cliente	 */	
	function view($id = null) {	  
	global $medico;	  
	$medico = find('medicos', $id);	}