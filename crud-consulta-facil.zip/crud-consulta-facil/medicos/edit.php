	<?php 	  
	require_once('functions.php'); 	  
	edit();	?>	
	<?php include(HEADER_TEMPLATE); ?>	
	
	<div id="light-grey-bg" class="container-fluid">
	<div id="section-contactus" class="container">

	<h2>Atualizar Médico</h2>
	<form action="edit.php?id=<?php echo $medico['id']; ?>" method="post">
	<hr />
	<div class="row">
		<div class="form-group col-md-7">	      
			<label for="name">Nome </label>	      
			<input type="text" class="form-control" name="medico['nome']" value="<?php echo $medico['nome']; ?>">	    
		</div>
		<div class="form-group col-md-5">	      
			<label for="campo2">Email</label>	      
			<input type="text" class="form-control" name="medico['email']" value="<?php echo $medico['email']; ?>">	    
		</div>

		<div class="form-group col-md-5">
			<label for="campo1">Senha</label>	      
			<input type="password" class="form-control" name="medico['senha']" value="<?php echo $medico['senha']; ?>">	    
		</div>
		<div class="form-group col-md-5">	      
			<label for="campo1">Endereço</label>	      
			<input type="text" class="form-control" name="medico['endereco']" value="<?php echo $medico['endereco']; ?>">	    
		</div>

		<div class="form-group col-md-2">	      
		<label for="campo3">Data de Cadastro</label>	      
		<input type="text" class="form-control" name="medico['data_criacao']" disabled value="<?php echo $medico['data_criacao']; ?>">	    
		</div>
	</div>

	<div id="actions" class="row">
	<div class="col-md-12">	      
	<button type="submit" class="btn btn-primary">Salvar</button>	      
	<a href="index.php" class="btn btn-default">Cancelar</a>	    
	</div>
	</div>
	</form>
	</div>
	</div>
	<?php include(FOOTER_TEMPLATE); ?>